package pkg.casosCovid;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/*
 * @author     Kleber Luiz dos Santos
 * @college    Universidade Est�cio
 * @discipline P�s Ci�ncia de Dados e BigData
 * @professor  Denis Gon�alves Cople
 */
public class CasoCovidReducer extends Reducer<Text,IntWritable,Text,IntWritable>{
	@Override
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {
		// C�digo Reduce acumulador de casos por Cidade
        int qtde = 0;
        for (IntWritable val : values) {
        	qtde += val.get();
        }
        context.write(key, new IntWritable(qtde));	    
	}
}
