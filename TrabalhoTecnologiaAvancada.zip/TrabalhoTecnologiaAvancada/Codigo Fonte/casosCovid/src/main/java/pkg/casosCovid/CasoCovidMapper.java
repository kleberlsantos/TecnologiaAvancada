package pkg.casosCovid;

import java.io.IOException;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

/*
 * @author     Kleber Luiz dos Santos
 * @college    Universidade Est�cio
 * @discipline P�s Ci�ncia de Dados e BigData
 * @professor  Denis Gon�alves Cople
 */
public class CasoCovidMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
	private static final String ESTADO = "BA";
	@Override
	public void map(LongWritable key, Text value, Context context)
		throws IOException, InterruptedException {
		//Recupera linha do arquivo
		String cLinha = value.toString();
		//Inclui as colunas em um Array de String
		String[] aLinha = cLinha.split(";");
		if (aLinha.length>0){
			String cEstado=aLinha[14];  // Estado (UF) com a divulga��o do Boletim di�rio
			String cTipoEntidade=aLinha[13]; // valores poss�veis city | state
			if (cTipoEntidade.equals("city")&&cEstado.equals(ESTADO)){ //Filtra para o Estado Especifico
				String cNomeCidade=aLinha[0]; // Nome da Cidade com a divulga��o do Boletim di�rio
				int nQtdeConfirmado=Integer.parseInt(aLinha[15]); // Quantidade de casos no dia do boletim
				//
				if (nQtdeConfirmado>0)
				  context.write(new Text(cNomeCidade), new IntWritable(nQtdeConfirmado));
			}			
		}		
	}
}
